import React from "react";
import { Link, withRouter } from "react-router-dom";
import { createHashHistory } from "history";

var flag = false;
export const history = createHashHistory();

class Contacts extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      flag: false
      // Set your state here
    };
    this.handleDashboard = this.handleDashboard.bind(this);
  }
  
  componentWillMount() {
    this.props.history.push("/contacts");
  }
  
  render = () => {
    return (
      <div>
        <h1>This is Contacts...</h1>
        <ul>
          <li>
            <Link to="/">Logout</Link>
          </li>
          <li>
            <Link onClick={this.handleDashboard}>Dashboard</Link>
          </li>
        </ul>
      </div>
    );
  };
  handleDashboard() {
    console.log(history);
    flag=true;
    if (flag) {
     this.props.history.push("/dashboard");
    }
  }
}

export default withRouter(Contacts);
