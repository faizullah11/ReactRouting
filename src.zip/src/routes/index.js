import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Parent from "./Home";
import Dashboard from "./Dashboard";
import Contacts from "./Contacts";

export default () => (
  <BrowserRouter>
    <Switch>
      <Route path="/" exact render={props => <Parent {...props} />} />
      <Route
        path="/dashboard"
        exact
        render={props => <Dashboard {...props} />}
      />
      <Route path="/contacts" exact render={props => <Contacts {...props} />} />
    </Switch>
  </BrowserRouter>
);
