import React from "react";
import { Link, withRouter } from "react-router-dom";
import { createHashHistory } from "history";

var flag = false;
export const history = createHashHistory();

class Dashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      flag: false
      // Set your state here
    };
    this.handleContacts = this.handleContacts.bind(this);
  }
  
  componentWillMount() {
    this.props.history.push("/dashboard");
  }
  
  render = () => {
    return (
      <div>
        <ul>
          <li>
            <Link to="/">Logout</Link>
          </li>
          <li>
            <Link onClick={this.handleContacts}>Contacts</Link>
          </li>
        </ul>

        <h1>This is Dashboard...</h1>
      </div>
    );
  };
  handleContacts() {
    console.log(history);
    flag=true;
    if (flag) {
     this.props.history.push("/contacts");
    //  window.location.replace("/contacts");
    }
  }
}

export default withRouter(Dashboard);
