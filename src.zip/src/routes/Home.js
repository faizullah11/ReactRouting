import React from "react";
import { withRouter } from "react-router-dom";
import { createHashHistory } from "history";

import "../App.css";
export const history = createHashHistory();

class Parent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      signup: false,
      login: true
      // Set your state here
    };
    this.switch = this.switch.bind(this);
  }
  componentWillMount() {
    this.props.history.push("/");
  }
  switch(word) {
    var signup, login;
    if (word === "signup") {
      signup = true;
      login = false;
    } else {
      login = true;
      signup = false;
    }
    return this.setState({ login: login, signup: signup });
  }
  render() {
    var self = this;
    return (
      <div>
        <a href="#space">For Login Click Here!</a>
        <div id="landing">
          <h1>Welcome To our Page </h1>
          <p>
            This website is with React JS user Interface (some fo code for login is taken from
            codePen) It is has basic functionalities like,
            <br />
            Routing the Pages and Cascading Style Sheets (CSS) are used to
            dictate the appearance
            <br />
            (the "look and feel") of this website. These styles are kept separate
            from <br />
            the HTML structure to allow for ease of updating and adherence to
            web standards.
          </p>
        </div>
        <div id="space">
          <div id="buttons">
            <p
              id="signupButton"
              onClick={self.switch.bind(null, "signup")}
              className={self.state.signup ? "yellow" : "blue"}
            >
              Sign Up
            </p>
            <p
              id="loginButton"
              onClick={self.switch.bind(null, "login")}
              className={self.state.login ? "yellow" : "blue"}
            >
              {" "}
              Login
            </p>
          </div>

          {self.state.signup ? <Signup /> : null}
          {self.state.login ? <Login /> : null}
        </div>
      </div>
    );
  }
}

class Signup extends React.Component {
  signUP(props) {
    var fNmAuth = document.getElementById("password").value;
    var emailAuth = document.getElementById("email").value;
    var psdAuth = document.getElementById("password").value;
    var cPdAuth = document.getElementById("password").value;

    //Routing 
    if (
      emailAuth != null &&
      psdAuth != null &&
      cPdAuth != null &&
      psdAuth === cPdAuth &&
      fNmAuth != null
    ) {
      console.log(history);
      window.location.replace("/dashboard");
      //below line Does work, because Signup class is not exporting
      // this.props.history.push('/dashboard'); //It Does not give output
    } else {
      alert("Try again");
    }
  }

  render() {
    return (
      <div>
        <div id="signup">
          <input type="text" id="first" placeholder="First Name" />
          <input type="text" id="last" placeholder="Last Name" />
          <input type="email" id="email" placeholder="Email" />
          <input type="password" id="password" placeholder="Password" />
          <input type="password" id="confirm" placeholder="Confirm Password" />
          <button id="send" onClick={this.signUP}>
            Send
          </button>
        </div>
      </div>
    );
  }
}


class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      emailAuth: false,
      psdAuth: false
    };
    this.auth = this.auth.bind(this);
  }

  auth(props) {
    var emailAuth = document.getElementById("email").value;
    var psdAuth = document.getElementById("password").value;
    //Routing
    if (emailAuth === "f" && psdAuth === "1") {
      console.log(history);
      window.location.replace("/dashboard");
      //below line Does work, because Login class is not exporting
      //this.props.history.push('/dashboard');  
    } else {
      alert("Try again");
    }
  }

  render() {
    return (
      <div>
        <div id="login">
          <input type="email" id="email" placeholder="Email" />
          <input type="password" id="password" placeholder="Password" />
          <button id="send" onClick={this.auth}>
            Send
          </button>
        </div>
      </div>
    );
  }
}

export default withRouter(Parent);
